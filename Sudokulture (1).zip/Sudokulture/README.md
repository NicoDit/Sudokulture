# Sudokulture

Développé par Nicolas Ditte et Clovis Masson
Contacts : nicolasditte0@gmail.com , clovismasson92@gmail.com

## Présentation de Sudokulture

Sodukulture est un jeu de sudoku accessible aux primaires. Pour chaque chiffre à trouver, un indice sous forme de question leur sera donné et la réponse à cette question sera une réponse du sudoku.
Ainsi ils travailleront à la fois leurs connaissances grâce aux indices et leurs logique de part la résolution du sudoku.
Il y a trois niveau de difficultés en fonction du nombre de chiffres à trouver, et lorque les trois niveau sont complétés il y a un dernier niveau bonus.

Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


## Utilisation de Sudokulture

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

./compile.sh
//compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

./run.sh Sudokulture
//lancement du jeu
