class Case{
    String chiffre;
    boolean decouvert;
    String indice;
}
