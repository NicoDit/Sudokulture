class Sudoku{
    Case[] cases;

}