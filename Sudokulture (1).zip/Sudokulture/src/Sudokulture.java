import extensions.File;
import extensions.CSVFile;
class Sudokulture extends Program{
    Case newCase(String chiffre, boolean decouvert, int combien){
        //Creer une nouvelle case avec un chiffre dedans et si il est découvert ou non
        File questions=newFile("../ressources/indices.txt");
        Case c = new Case();
        c.chiffre = chiffre;
        c.decouvert = decouvert;
        for (int i=0; i<(stringToInt(chiffre)-1)*9+stringToInt(chiffre);i+=1){
            readLine(questions);
        }
        
        for (int j=0;j<combien;j+=1){
            c.indice=readLine(questions);
        }
        return c;
    }

    Sudoku newSudoku(CSVFile nombres){
        //Créer un nouveau Sudoku de 81 cases à partir d'un fichier csv donné en paramètre
        Sudoku s = new Sudoku();
        s.cases = new Case[81];
        for(int i=0;i<rowCount(nombres);i+=1){
            for(int j=0;j<columnCount(nombres);j+=1){
                String chiffre=substring(getCell(nombres, i, j),0,1);
                boolean decouvert=charAt(getCell(nombres, i, j),1)==' ';
                s.cases[i*9+j]=newCase(chiffre, decouvert, i+1);
            }
        }
        return s;
    }

    CSVFile choixSudoku(String niveau, String sauv){
        //Retourne le fichier CSV contenant le Sudoku du niveau donné en paramètre
        CSVFile sudoku=loadCSV("../ressources/sudokus/"+niveau+sauv+".csv");
        return sudoku;
    }

    void sauv(Sudoku s, String niveau){
        //Sauvegarde l'état du Sudoku dans un fichier selon la difficulté" du Sudoku
        String[][] tab=new String[9][9];
        for(int i=0;i<9;i+=1){
            for(int j=0;j<9;j+=1){
                char decouvert=':';
                if(s.cases[i*9+j].decouvert){
                    decouvert=' ';
                }
                tab[i][j]=s.cases[i*9+j].chiffre+decouvert;
            }
        }
        saveCSV(tab, "../ressources/sudokus/"+niveau+"Sauv.csv");
    }

    void reinitialiser(){
        //Réinitialise la sauvegarde courante des fichiers du joueur
        println("Es tu sûr de vouloir reinitialiser ta progression ?");
        print("Appuie sur entree pour continuer ou entre 0 pour annuler : ");
        String reinit=readString();
        if(!equals(reinit,"0")){
            Sudoku s=newSudoku(choixSudoku("facile","Init"));
            sauv(s, "facile");
            s=newSudoku(choixSudoku("intermediaire","Init"));
            sauv(s, "intermediaire");
            s=newSudoku(choixSudoku("difficile","Init"));
            sauv(s, "difficile");
            s=newSudoku(choixSudoku("bonus","Init"));
            sauv(s, "bonus");
            clearScreen();
            println("La progression a été reinitialisée.");    
        }else{
            clearScreen();
        } 
    }



    boolean estFini(Sudoku s){
        //Vérifie si le sudoku est terminé ou non
        boolean estFini=true;
        for(int i=0;i<length(s.cases);i+=1){
            if(s.cases[i].decouvert==false){
                estFini=false;
            }
        }
        return estFini;
    }

    boolean testEstFini(){
        Sudoku s=newSudoku(choixSudoku("facile","Complet"));
        assertTrue(estFini(s));
        return true;
    }

    boolean accesBonus(){
        //Renvoie true si le joueur a fini tous les Sudokus pour avoir acces à un niveau bonus
        boolean accesBonus=true;
        Sudoku s1=newSudoku(choixSudoku("facile","Sauv"));
        Sudoku s2=newSudoku(choixSudoku("intermediaire","Sauv"));
        Sudoku s3=newSudoku(choixSudoku("difficile","Sauv"));
        if(!estFini(s1) || !estFini(s2) || !estFini(s3)){
            accesBonus=false;
        }
        return accesBonus;    
    }

    boolean testAccesBonus(){
        boolean accesBonus=true;
        Sudoku s1=newSudoku(choixSudoku("facile","Complet"));
        Sudoku s2=newSudoku(choixSudoku("intermediaire","Complet"));
        Sudoku s3=newSudoku(choixSudoku("difficile","Complet"));
        if(!estFini(s1) || !estFini(s2) || !estFini(s3)){
            accesBonus=false;
        }
        assertTrue(accesBonus);
        return accesBonus;
    }

    int saisiePosition(Sudoku s){
        //Renvoie l'indice dans le tableau de la positon saisie si celle-ci est correcte
        String position=toUpperCase(readString());
        if(equals(position,"0")){
            return -3;
        }
        if((length(position)==2) && (charAt(position,0)>='A' && charAt(position,0)<='I' && charAt(position,1)>='1' && charAt(position,1)<='9')){
            int positionCase=(int)((charAt(position,0)-'A')*9+(charAt(position,1)-'1'));
            if(s.cases[positionCase].decouvert==false){
                return positionCase;
            }else{
                return -1;
            }
            
        }else{
            return -2;
        }
        
    }


    boolean decouvrirCase(Sudoku s, int position, String valeur){
        //Découvre le chiffre si la réponse donnée est correcte
        
        if(equals(s.cases[position].chiffre,valeur)){
            s.cases[position].decouvert=true;
            return true;
        }else{
            return false;
        }
        
    }

    boolean testDecouvrirCase(){
        Sudoku s=newSudoku(choixSudoku("facile","Init"));
        assertTrue(decouvrirCase(s,1,"4"));
        return true;
    }

    String choixNiveau(){
        //Affiche du texte pour que le joueur puisse choisir la difficulté qu'il souhaite et la renvoie
        println("Jouer : 1)Facile 2)Intermediaire 3)Difficile");
        println();
        print("Choisis un niveau (0 pour revenir au menu): ");
        String niveau="";
        while(true){
            niveau=readString();
            if(equals(niveau,"1")){
                clearScreen();
                return "facile";
            }else if(equals(niveau,"2")){
                clearScreen();
                return "intermediaire";
            }else if(equals(niveau,"3")){
                clearScreen();
                return "difficile";
            }else if(equals(niveau,"0")){
                clearScreen();
                return "";
            }
        }
        
    }

    Boolean testChoixNiveau(){
        assertEquals(choixNiveau(),"facile");
        return true;
    }

    boolean jouerSudoku(Sudoku s){
        //Permet au joueur de jouer au Sudoku donné en paramètre
        boolean stop=false;
        String message="";
        while(!estFini(s) && !stop){
            
            int position=-1;
            while(position==-1 || position==-2){
                clearScreen();
                afficher(s);
                println(message);
                print("Selectionne la case (0 pour revenir au menu): ");
                position=saisiePosition(s);
                if(position==-3){
                    stop=true;
                }else if(position==-2){
                   message="position invalide";
                }else if(position==-1){
                    message="Chiffre déjà découvert !";
                }else{
                    clearScreen();
                    message="";
                    afficherSelection(s, position);
                    println("Indice : "+s.cases[position].indice);
                    print("Entre la solution ! (0 pour revenir en arriere): ");
                    String reponse ="";
                    do{
                        reponse=readString();
                        if(decouvrirCase(s, position, reponse)){
                            message="Bonne réponse !";
                        }else{
                           println("NON");
                        }
                    }while(!equals(reponse,"0") && !decouvrirCase(s, position, reponse));
                }
            }
            
        }
        return estFini(s);
    }

    

    void montrerMenu(){
        //Affiche le menu du jeu
        println("___Menu___");
            println("1. Jouer");
            println("2. Règles");
            println("3. Reinitialiser");
            println("0. Quitter");
            println();
            print("Choisis ce que tu veux faire en entrant le chiffre correspondant: ");
    }

    void montrerRegles(){
        //Affice les règles du jeu
        clearScreen();
        println("Voici les règles:");
        println();
        println("-Le principe du Sudoku est que dans chaque case, chaque ligne et chaque colonne les chiffres de 1 à 9 apparaissent une et une seule fois");
        println("-Tu dois alors utiliser la logique pour compléter les chaque Sudoku");
        println("-Tu pourras choisir entre 3 difficultés de Sudokus");
        println("-Pour t'aider à compléter les Sudokus tu auras le droit à un indice à chaque fois que tu sélectionne une cellule à compléter");
        println("-Cet indice sera une question de culture et la réponse à cette question sera le chiffre à compléter");
        println("-Pour selectionner une cellule à compléter tu devras écrire la lettre correspondante à la ligne et puis le chiffre correspondant à la colonne. Ex:B2 ou d4");
        println();
        println("Appuie sur entrée pour revenir au menu");
        readString();
        clearScreen();
    }


    void afficher(Sudoku s){
        //Permet d'afficher un sudoku de 9x9
        int indice=0, indiceLettre=0;
        println(" | 1 2 3 | 4 5 6 | 7 8 9 |");
        for(int l=0;l<3;l+=1){
            println("--------------------------");
            for(int k=0;k<3;k+=1){
                print((char)('A'+indiceLettre));
                indiceLettre+=1;
                for(int j=0;j<3;j+=1){
                    print("| ");
                    for(int i=0;i<3;i+=1){
                        if(s.cases[indice].decouvert){
                            print(s.cases[indice].chiffre+" ");
                        }else{
                            print("_ ");
                        }
                        indice+=1;
                    }
                }
                println("|");
                
            }
        }
        println("--------------------------");
    }

    void afficherSelection(Sudoku s,int position){
        //Permet d'afficher le Sudoku en mettant en avant la case sélectionnée
        int indice=0, indiceLettre=0;
        println(" | 1 2 3 | 4 5 6 | 7 8 9 |");
        for(int l=0;l<3;l+=1){
            println("--------------------------");
            for(int k=0;k<3;k+=1){
                print((char)('A'+indiceLettre));
                indiceLettre+=1;
                for(int j=0;j<3;j+=1){
                    print("| ");
                    for(int i=0;i<3;i+=1){
                        if(indice!=position){
                            if(s.cases[indice].decouvert){
                                print(s.cases[indice].chiffre+" ");
                            }else{
                                print("_ ");
                            }
                            
                        }else{
                            print("X ");
                        }
                        indice+=1;
                        
                    }
                }
                println("|");
                
            }
        }
        println("--------------------------");
    }

    void algorithm(){
        //Sudoku dans un fichier csv avec un ':' a cote des chiffres non-decouverts de base
        String reponseMenu="";
        boolean fini=false, accesBonus=false;
        clearScreen();
        println("Bienvenue dans Sudokulture !");
        do{
            println();
            montrerMenu();
            reponseMenu=readString();
            println();

            if(equals(reponseMenu,"1")){
                if(!accesBonus){
                    clearScreen();
                    String niveau=choixNiveau();
                    if(!equals(niveau,"")){
                        Sudoku s=newSudoku(choixSudoku(niveau,"Sauv"));
                        fini=jouerSudoku(s);
                        sauv(s, niveau);
                        clearScreen();
                        if(fini){
                            println("Tu as réussi le sudoku "+niveau+ " !");
                            accesBonus=accesBonus();
                            if(accesBonus){
                                println();
                                println("Tu as débloqué un niveau bonus, va voir !");
                            }
                        }
                    }
                    
                }else{
                    clearScreen();
                    Sudoku s=newSudoku(choixSudoku("bonus", "Sauv"));
                    fini=jouerSudoku(s);
                    sauv(s, "bonus");
                    clearScreen();
                    if(fini){
                        println("Bravo tu as fini le jeu!");
                    }
                }
                
            }else if(equals(reponseMenu,"2")){
                montrerRegles();
            }else if(equals(reponseMenu,"3")){
                reinitialiser();
            }
        }while(!equals(reponseMenu,"0"));
    }

}